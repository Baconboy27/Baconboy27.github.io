Check out my portfolio! -> https://georgedash.github.io
=

This is my third project and is my first **serious** one, because here I can truly show my skills in HTML and CSS (and a bit of JavaScript, too).
<br>
It was kinda hard for me to come up with the design, so I want to *hugely* thank Alex and his [Amberite Personal Portfolio Demo](https://amberite.framer.website/) for the inspiration!
<br>
I also want to thank *Alex with Coding* and his [Reading Progress Bar JavaScript/CSS Tutorial](https://www.youtube.com/watch?v=ZF1hXoq8Lk0) for the scrollbar idea, because this fixed **a lot** of design issues in my website!
<br>
And last, but definitely not least - I want to give a **huge** shoutout to *michalsnik* and his [AOS - Animate On Scroll](https://github.com/michalsnik/aos/tree/v2) library.
